-- TASK3 / CREAZIONE E POPOLAZIONE DELLE TABELLE


--CREAZIONE TABELLA PRODUCT

CREATE TABLE Product (
    ProductID INT NOT NULL,
	CategoryID INT NOT NULL,
    NameProduct VARCHAR(25),
    DateProduction DATE,
    VersionProduct VARCHAR(50),
	Agecheck INT
	
);

--POPOLAZIONE TABELLA PRODUCT

INSERT INTO Product (ProductID, CategoryID, NameProduct, DateProduction, VersionProduct, Agecheck)
VALUES
(1, 1, 'Cyberpunk 2077', '2022-01-15', 'V1.0', 3),
(2, 2, 'Red Dead Redemption 2', '2022-02-20', 'V2.1', 5),
(3, 3, 'Dungeons', '2022-03-10', 'V1.5', 2),
(4, 4, 'Final Fantasy VII Remake', '2022-04-05', 'V2.0', 4),
(5, 4, 'The Witcher 3: Wild Hunt', '2022-05-12', 'V1.2', 6),
(6, 2, 'Fortnite', '2022-06-25', 'V1.8', 1),
(7, 2, 'Call of Duty: Warzone', '2022-07-08', 'V2.5', 2),
(8, 2, 'Minecraft', '2022-08-14', 'V1.3', 4),
(9, 1, 'Super Mario Odyssey', '2022-09-19', 'V2.2', 5),
(10, 4, 'Sonic', '2022-10-30', 'V1.7', 3);

--CHECK CORRETTA OPERAZIONE
Select *
From Product


--CREAZIONE TABELLA SALES
CREATE TABLE Sales (
    SalesID INT NOT NULL,
	ProductID INT NOT NULL,
	RegionID INT NOT NULL,
    Quantity INT,
    DateSales DATE,
    SalesAmount DECIMAL (10,2),
	);

	--POPOLAZIONE TABELLA SALES

	INSERT INTO Sales (SalesID, ProductID, RegionID, Quantity, DateSales, SalesAmount)
VALUES
(1, 1, 1, 50, '2023-01-15', 1500.75),
(2, 2, 2, 30, '2023-02-20', 900.50),
(3, 2, 1, 25, '2023-03-10', 750.25),
(4, 6, 3, 40, '2023-04-05', 1200.00),
(5, 7, 2, 20, '2023-05-12', 600.40),
(6, 5, 3, 35, '2023-06-25', 1050.60),
(7, 5, 1, 45, '2023-07-08', 1350.90),
(8, 1, 2, 28, '2023-08-14', 850.75),
(9, 1, 3, 33, '2023-09-19', 990.30),
(10, 10, 1, 22, '2023-10-30', 660.80);

--CHECK CORRETTA OPERAZIONE
Select *
From Sales

--CREAZIONE TABELLA REGION
CREATE TABLE Region  (
  RegionID INT NOT NULL,
  RegionName VARCHAR (20),
  StateName VARCHAR (20)
  
	);

	--POPOLAZIONE TABELLA REGION
INSERT INTO Region (RegionID, RegionName, StateName)
VALUES
(1, 'Nord America', 'Stati Uniti'),
(2, 'Nord America', 'Canada'),
(3, 'Europa', 'Francia'),
(4, 'Europa', 'Germania'),
(5, 'Asia', 'Giappone'),
(6, 'Asia', 'Cina'),
(7, 'Africa', 'Nigeria'),
(8, 'Africa', 'Sudafrica'),
(9, 'America del Sud', 'Brasile'),
(10, 'America del Sud', 'Argentina'),
(11, 'Oceania', 'Australia'),
(12, 'Europa', 'Italia'),
(13, 'Asia', 'India'),
(14, 'Africa', 'Egitto'),
(15, 'America del Nord', 'Messico'),
(16, 'Europa', 'Regno Unito');

--CHECK CORRETTA ESECUZIONE

Select *
From Region

--CREAZIONE TABELLA CATEGORY
CREATE TABLE Category (
    CategoryID INT NOT NULL,
	CategoryName VARCHAR (20),
	);

--POPOLAZIONE TABELLA CATEGORY
INSERT INTO Category (CategoryID, CategoryName)
VALUES
(1, 'Azione'),
(2, 'Avventura'),
(3, 'Sport'),
(4, 'RPG'),
(5, 'Sparatutto'),
(6, 'Strategia'),
(7, 'Simulazione'),
(8, 'Puzzle'),
(9, 'Horror'),
(10, 'Indie');

--CHECK CORRETTA ESECUZIONE
Select*
From Category


-- TASK 4/1 DEFINIZIONE CHIAVI

ALTER TABLE Product
ADD PRIMARY KEY (ProductID);

ALTER TABLE Category
ADD PRIMARY KEY (CategoryID);

ALTER TABLE Sales
ADD PRIMARY KEY (SalesID);

ALTER TABLE Region
ADD PRIMARY KEY (RegionID);

ALTER TABLE Product
ADD FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID);

ALTER TABLE Sales
ADD FOREIGN KEY (ProductID) REFERENCES Product(ProductID);

ALTER TABLE Sales
ADD FOREIGN KEY (RegionID) REFERENCES Region(RegionID);


-- TASK 4/1 -  Verificare che i campi definiti come PK siano univoci.

SELECT COUNT(*), ProductID
FROM Product
GROUP BY ProductID
HAVING COUNT(*) > 1

SELECT COUNT(*), CategoryID
FROM Category
GROUP BY CategoryID
HAVING COUNT(*) > 1

SELECT COUNT(*), SalesID
FROM Sales
GROUP BY SalesID
HAVING COUNT(*) > 1

SELECT COUNT(*), RegionID
FROM Region
GROUP BY RegionID
HAVING COUNT(*) > 1


-- TASK 4/2 - 2)	Esporre l�elenco delle transazioni indicando nel result set...

SELECT
    s.SalesID AS CodiceDocumento,
    s.DateSales AS Data,
    p.NameProduct AS NomeProdotto,
    c.CategoryName AS CategoriaProdotto,
    r.StateName AS NomeStato,
    rg.RegionName AS NomeRegione,
    CASE WHEN DATEDIFF(DAY, s.DateSales, GETDATE()) > 180 THEN 'Vero' ELSE 'Falso' END AS Passati180Giorni
FROM
    Sales s
JOIN
    Product p ON s.ProductID = p.ProductID
JOIN
    Category c ON p.CategoryID = c.CategoryID
JOIN
    Region r ON s.RegionID = r.RegionID
JOIN
    Region rg ON s.RegionID = rg.RegionID;


	-- TASK 4/3 - Esporre l�elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 

	SELECT
    p.ProductID,
    p.NameProduct AS NomeProdotto,
    YEAR(s.DateSales) AS Anno,
    SUM(s.SalesAmount) AS FatturatoTotale
FROM
    Sales s
JOIN
    Product p ON s.ProductID = p.ProductID
GROUP BY
    p.ProductID, p.NameProduct, YEAR(s.DateSales);




-- TASK 4/4 - Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.

SELECT
    r.StateName AS NomeStato,
    YEAR(s.DateSales) AS Anno,
    SUM(s.SalesAmount) AS FatturatoTotale
FROM
    Sales s
JOIN
    Region r ON s.RegionID = r.RegionID
GROUP BY
    r.StateName, YEAR(s.DateSales)
ORDER BY
    YEAR(s.DateSales) ASC, SUM(s.SalesAmount) DESC;


-- TASK 4/5 - Rispondere alla seguente domanda: qual � la categoria di articoli maggiormente richiesta dal mercato?
--La categoria pi� richiesta al momento � la categoria "Avventura", per scoprirlo ho effettuato questa query:

SELECT
    c.CategoryName AS Categoria,
    SUM(s.Quantity) AS QuantitaTotaleVenduta
FROM
    Sales s
JOIN
    Product p ON s.ProductID = p.ProductID
JOIN
    Category c ON p.CategoryID = c.CategoryID
GROUP BY
    c.CategoryName
ORDER BY
    SUM(s.Quantity) DESC;


-- 4/6 Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.

-- 1) APPROCCIO
SELECT
    ProductID,
    NameProduct AS NomeProdotto
FROM
    Product p
WHERE
    NOT EXISTS (
        SELECT 1
        FROM Sales s
        WHERE p.ProductID = s.ProductID
    );

	-- 2) APPROCCIO
	SELECT
    p.ProductID,
    p.NameProduct AS NomeProdotto
FROM
    Product p
LEFT JOIN
    Sales s ON p.ProductID = s.ProductID
WHERE
    s.SalesID IS NULL;


	-- 4/7 Esporre l�elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita pi� recente).

	SELECT
    p.ProductID,
    p.NameProduct AS NomeProdotto,
    MAX(s.DateSales) AS UltimaDataVendita
FROM
    Product p
LEFT JOIN
    Sales s ON p.ProductID = s.ProductID
WHERE
    s.DateSales IS NOT NULL
GROUP BY
    p.ProductID, p.NameProduct;


	-- 4/8 8)	Creare una vista sui prodotti in modo tale da esporre una �versione denormalizzata� delle informazioni utili (codice prodotto, nome prodotto, nome categoria)

	CREATE VIEW View_Product AS
SELECT
    p.ProductID AS CodiceProdotto,
    p.CategoryID,
    c.CategoryName AS NomeCategoria,
    p.NameProduct AS NomeProdotto,
    p.DateProduction AS DataProduzione,
    p.VersionProduct AS VersioneProdotto,
    p.Agecheck AS ControlloEt�
FROM
    Product p
JOIN
    Category c ON p.CategoryID = c.CategoryID;

	
	-- 4/9 Creare una vista per restituire una versione �denormalizzata� delle informazioni geografiche

	CREATE VIEW Region_View AS
SELECT
    r.RegionID,
    r.RegionName AS NomeRegione,
    r.StateName AS NomeStato
FROM
    Region r;

--------------------------------------------------------



	CREATE VIEW View_Sales2 AS
SELECT
    SalesID AS CodiceDocumento,
    ProductID,
    RegionID,
    Quantity,
    DateSales AS DataVendita,
    SalesAmount AS ImportoVendita
FROM
    Sales;


	CREATE VIEW View_Category AS
SELECT
    CategoryID AS CodiceCategoria,
    CategoryName AS NomeCategoria
FROM
    Category;